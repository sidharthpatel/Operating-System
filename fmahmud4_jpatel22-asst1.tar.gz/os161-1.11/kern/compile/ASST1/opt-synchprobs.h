/* Automatically generated; do not edit */
#ifndef _OPT_SYNCHPROBS_H_
#define _OPT_SYNCHPROBS_H_
#define OPT_SYNCHPROBS 1
#endif /* _OPT_SYNCHPROBS_H_ */
