/*
 * getpidtest to test getpid
 */

#include <unistd.h>
#include <err.h>

static volatile int pid;

int
main()
{

		pid = getpid();
    printf("getpid works! current pid: %d\n", pid);

    return 0;
}
