/*
 * execvtest to test execv
 */

#include <unistd.h>
#include <err.h>


int
main()
{

    char *prog = "testbin/add";
    char *args[4] = {"add", "1", "2", NULL};

    execv(prog, args);
    printf("execv is working\n");
    return 0;
}
