/*
 * getppidtest to test getppid
 */

#include <unistd.h>
#include <err.h>

static volatile int ppid;

int
main()
{

		ppid = getppid();
    printf("getppid works! current parent pid: %d\n", ppid);

    return 0;
}
