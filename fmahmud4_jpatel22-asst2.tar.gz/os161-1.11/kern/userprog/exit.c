#include <types.h>
#include <lib.h>
#include <thread.h>
#include <vm.h>
#include <synch.h>
#include <vm.h>
#include <vfs.h>
#include <curthread.h>


int sys__exit(int code){
  //check if the parent even exists or else we dont need the exit code
  if(curthread->t_process->p_pid > 0) {
	  lock_acquire(curthread->t_process->p_lock); 
	
	  processList[curthread->t_process->pid]->exit_code = code; 
	  processList[curthread->t_process->pid]->has_exited = 1;
    V(curthread->t_process->p_sem);
	  lock_release(curthread->t_process->p_lock);

    //P(curthread->t_process->p_sem);

  }

  //thread clean up happens in thread_exit();
  /*
  sem_destroy(curthread->t_process->p_sem);
  lock_destroy(curthread->t_process->p_lock);
  processList[curthread->t_process->pid] = 0;	
  kfree(curthread->t_process);
  */

  thread_exit(); 
	return 0; 
}
