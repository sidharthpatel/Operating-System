#include <types.h>
#include <synch.h>
#include <lib.h>
#include <kern/errno.h>
#include <thread.h>
#include <curthread.h>

int sys_waitpid(pid_t pid, userptr_t status, int options, int *retval) {
  struct process *childproc = processList[(int)pid];
  int err;
	if((pid < 0) || (options != 0)){
		*retval = -1; 
		return EINVAL; /*Invalid argument*/
	}

	if(status == NULL) {
		*retval = -1; 
		return EFAULT; /*Bad memory reference*/
	}

	//We need to double check whether the parent process is pointing to null 
	if(processList[curthread->t_process->pid] == NULL) {
		*retval = -1; 
		return EINVAL; //Invalid argunment
	}

 
  
  //check if the child process has exited
  if(!childproc->has_exited) {

    //now must block the parent until child exits to reap and get exit code 
    P(childproc->p_sem);
  }
  
  //copy the pid between user and kernel
  
  err = copyout(&childproc->exit_code, status, sizeof(int));

  if(err) {
   *retval = -1;
   return err;
  }

  

  *retval = pid;
  // kprintf("curthreads->pid%d\n", curthread->t_process->pid); 
  //signal to exiting thread that it is okay to exit fully
  //V(curthread->t_process->p_sem);
	
  return 0; 
}
