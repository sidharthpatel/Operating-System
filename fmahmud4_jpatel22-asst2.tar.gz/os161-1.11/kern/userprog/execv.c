#include <types.h>
#include <kern/unistd.h>
#include <kern/errno.h>
#include <lib.h>
#include <addrspace.h>
#include <thread.h>
#include <curthread.h>
#include <vm.h>
#include <vfs.h>
#include <syscall.h>
#include <vnode.h>

#define MAX_NUM_ARGS 64
#define MAX_PATH_SIZE 256

int sys_execv(char *progname, char **args) {
  struct vnode *v;
  vaddr_t entrypoint, stackptr;
  int result, i, arg_size, argc = 0;
  char *kname;
  char **kargs;
  char **uspace;
  size_t actual, actual_arg;

  if(progname == NULL) {
    return ENOENT;
  }
  int progname_size = strlen(progname)+1;
  if(args == NULL) {
    return EFAULT;
  }
  

  /* copyin args from user -> kernel space */

  while(args[argc] != NULL) {
    argc++;
  }
 
  if(argc > MAX_NUM_ARGS) {
    return E2BIG;

  }

  //copy in progname for kernel
  kname = (char *) kmalloc(sizeof(char*)*progname_size);
  if(kname == NULL) {
    kfree(kname);
    return ENOMEM;
  }

  result = copyinstr((const_userptr_t) progname, kname, (sizeof(char*)*progname_size), &actual);
  if(result) {
    kfree(kname);
    return result;
  }


 
  kargs = (char **) kmalloc(sizeof(char**)*MAX_NUM_ARGS);
  if(kargs == NULL) {
    kfree(kname);
    kfree(kargs);
    return ENOMEM;
  }

  //copy in userargs to kern args
  
  for(i = 0; i < argc; i++) {
    //makes sure we have enough space for the argument
    arg_size = strlen(args[i])+1;

    kargs[i] = (char *) kmalloc(sizeof(char*)*arg_size);
    
    result = copyinstr((const_userptr_t) args[i], kargs[i], (size_t)arg_size, &actual_arg);
    if(result) {
      kfree(kname);
      kfree(kargs);
      return result;
    }
  }

  //null terminate the kargs
  kargs[argc] = NULL;

	/* Open the file. */
	result = vfs_open(progname, O_RDONLY, &v);
	if (result) {
		return result;
	}

  //TODO: DELETE THIS WHEN WORKING WITH menu.c version of execv
  curthread->t_vmspace = NULL;
	
  /* We should be a new thread. */
	assert(curthread->t_vmspace == NULL);
	/* Create a new address space. */
	curthread->t_vmspace = as_create();
	if (curthread->t_vmspace==NULL) {
		vfs_close(v);
		return ENOMEM;
	}

	/* Activate it. */
	as_activate(curthread->t_vmspace);

	/* Load the executable. */
	result = load_elf(v, &entrypoint);
	if (result) {
		/* thread_exit destroys curthread->t_vmspace */
		vfs_close(v);
		return result;
	}

	/* Done with the file now. */
	vfs_close(v);

	/* Define the user stack in the address space */
	result = as_define_stack(curthread->t_vmspace, &stackptr);
	if (result) {
		/* thread_exit destroys curthread->t_vmspace */
		return result;
	}

  //copyout args from kernel -> user stack (stackptr)
  

  uspace = (char **) kmalloc(sizeof(char**)*MAX_NUM_ARGS);
  if(uspace == NULL) {
    kfree(kname);
    kfree(kargs);
    kfree(uspace);
    return ENOMEM;
  }


  size_t ustack = 0;


  for(i = 0; i < argc; i++) {
    arg_size = strlen(kargs[i])+1;
    char *uarg = kargs[i];
    int padding = 4 - (arg_size%4);
    int total_arg_size = arg_size;
    
    //enforces memory alignment
    if(arg_size%4 > 0) {
      total_arg_size = arg_size + (4 - arg_size%4);
    }

    //pads the uarg with null terminator strings
    while(arg_size != total_arg_size) {
      uarg[arg_size] = '\0';
      arg_size++;
    }
    if(i == 0) {
      ustack = stackptr - (size_t) arg_size;
    }
    else {
      ustack = (size_t) uspace[i-1] - (size_t) arg_size;
    }
    result = copyoutstr(uarg, (userptr_t) ustack, (size_t)arg_size, &actual_arg);
    if(result) {
      kfree(kname);
      kfree(kargs);
      kfree(uspace);
      return result;
    }

    uspace[i] = (char*) ustack;
  }
  
  uspace[argc] = NULL;
  ustack = (size_t)uspace[argc-1] - (argc+2)*sizeof(char*);
  result = copyout(uspace, (userptr_t) ustack, (argc+2)*sizeof(char*));
  if(result) {
    return result;
  }





	/* Warp to user mode. */
	md_usermode(argc, (userptr_t)ustack, ustack, entrypoint);
	


  return 0;
}

