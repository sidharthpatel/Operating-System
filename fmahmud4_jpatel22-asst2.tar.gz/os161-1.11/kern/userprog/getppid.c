#include <types.h>
#include <curthread.h> 
#include <thread.h> 
#include <syscall.h>

int sys_getppid(int *retval){
	
  *retval = curthread->t_process->p_pid; 
	
  return 0; 
}
