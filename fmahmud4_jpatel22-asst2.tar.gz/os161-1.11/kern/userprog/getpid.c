#include <types.h>
#include <curthread.h> 
#include <thread.h> 
#include <syscall.h>

int sys_getpid(int *retval) {
	
  *retval = curthread->t_process->pid; 

  return 0; 
}
