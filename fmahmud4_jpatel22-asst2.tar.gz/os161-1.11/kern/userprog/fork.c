#include <kern/errno.h>
#include <types.h>
#include <lib.h>
#include <thread.h>
#include <curthread.h>
#include <syscall.h>
#include <machine/trapframe.h>
#include <addrspace.h>



int sys_fork(struct trapframe *tf, int *retval) {
  
  struct thread *child;
  struct trapframe *parent_tf;
  int ret;

  parent_tf = kmalloc(sizeof(struct trapframe));
  
  
  if(parent_tf == NULL) {
      return ENOMEM;
  }
  
  if(curthread->t_vmspace == NULL) {
      return ENOMEM;
  }


  //copy the parent trapframe over
  
  memcpy(parent_tf, tf, sizeof(struct trapframe));

  int p_pid = curthread->t_process->pid;

  //make child process
 
  ret = thread_fork(curthread->t_name, parent_tf, p_pid, md_forkentry, &child);
 
  if(ret > 0) {
    return ret;
  }


  *retval =  child->t_process->pid;

   return 0;


}
