/* Automatically generated; do not edit */
#ifndef _OPT_NET_H_
#define _OPT_NET_H_
#define OPT_NET 0
#endif /* _OPT_NET_H_ */
